﻿using DriveCentric.BaseService.Services;
using DriveCentric.BusinessLogic.Interfaces;
using DriveCentric.Model;
using DriveCentric.Utilities.Context;

namespace DriveCentric.$safeprojectname$.Services
{
    public class $safeprojectname$Service : BaseService<$safeprojectname$>, I$safeprojectname$Service
    {
        public $safeprojectname$Service(
            IContextInfoAccessor contextInfoAccessor,
            I$safeprojectname$Logic businessLogic
            ) : base(contextInfoAccessor, businessLogic)
        { }
    }
}
