﻿using DriveCentric.BaseService.Interfaces;
using DriveCentric.Model;

namespace DriveCentric.$safeprojectname$.Services
{
    public interface I$safeprojectname$Service : IBaseService<$safeprojectname$> { }
}
